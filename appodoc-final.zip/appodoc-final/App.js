import * as React from 'react';
import MainContainer from './MainContainer';

function App() {
  return (
    <MainContainer/>
  );
}

export default App